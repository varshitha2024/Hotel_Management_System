import './index.css';
import {Link,useHistory} from 'react-router-dom';
import { useState } from 'react';

const CardAdminRoomAdd=()=>{

    const [type, setType] = useState("");
    const [noofbeds, setBeds] = useState(0);
    const [price, setPrice] = useState("");
    const [totalRooms, setTotalRooms] = useState("");
    const [roomsLeft, setRoomsLeft] = useState("");
    const [roomrating, setRoomRating] = useState("");
    const [facilities, SetFacilities] = useState("");
    const [image, setImage] = useState("");

    const submitHandler = (event) => {
        event.preventDefault();
        const roomInfo ={
            roomType: type,
            numberOfBeds: noofbeds,
            roomPrice: price,
            totalRooms: totalRooms,
            roomsLeft: roomsLeft,
            imageUrl: image,
            facilities: facilities,
            roomRating: roomrating
        };
        addRoomHandler(roomInfo);
        event.target.reset();
    }


    const addRoomHandler = async (roomInfo)=> {
        const response = await fetch('http://localhost:8080/api/addRoom', {
          method: 'POST',
          body: JSON.stringify(roomInfo),
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
          }
        });
        const data = await response.json();
        alert(data.message);
      }
    return(
        <div className='hotelcard11'>
            <form onSubmit={submitHandler}>
                <p>
                    <label>Choose a car:</label>
                    <select onChange={(e) => setType(e.target.value)}>
                        <option value="AC">AC</option>
                        <option value="NON-AC">NON-AC</option>
                        <option value="Deluxe">Deluxe</option>
                        <option value="Super Deluxe">Super Deluxe</option>
                        <option value="Suite">Suite</option>
                        <option value="Presidential Suite">Presidential Suite</option>
                    </select>
                </p>
                <p>
                    <label>Number of Beds</label>
                    <input type="number" onChange={(e) => setBeds(e.target.value)}></input>
                </p>
                <p>
                    <label>Room Price in $</label>
                    <input type="text" onChange={(e) => setPrice(e.target.value)}></input>
                </p>
                <p>
                    <label>Total Rooms</label>
                    <input type="text" onChange={(e) => setTotalRooms(e.target.value)}></input>
                </p>
                <p>
                    <label>Rooms Left</label>
                    <input type="text" onChange={(e) => setRoomsLeft(e.target.value)}></input>
                </p>
                <p>
                    <label>Room Rating</label>
                    <input type="text" onChange={(e) => setRoomRating(e.target.value)}></input>
                </p>
                <p>
                    <label>Facilities Seprated By Comma: </label>
                    <input type="text"  placeholder="Facilities Seprated By Comma"onChange={(e) => SetFacilities(e.target.value)}></input>
                </p>
                <p>
                    <label>Image URL</label>
                    <input type="text"  onChange={(e) => setImage(e.target.value)}></input>
                </p>
                <p>
                    <label>Add Room</label>
                    <input type="submit" value='Add'></input>
                </p>
            </form>
        </div>
    )
}
export default CardAdminRoomAdd;