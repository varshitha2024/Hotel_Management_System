import './index.css';
import React, {useState} from 'react';
import {useHistory} from 'react-router-dom';

const UserSigninCard=()=>{

    const history = useHistory();


    const [email, setEmail] = useState("");
    
    const [password, setPassword] = useState("");

    const submitHandler = (event) => {
        event.preventDefault();
        if(email=== ''){
            alert("Please enter Email");
        }
        else if(password=== ''){
            alert("Please Enter Password");
        }
        else{
            signinUserHandler(email, password);
            history.push('/home');
        }
      };

      const signinUserHandler = async (email, password)=> {
        const response = await fetch('http://localhost:8080/api/userLogin/'+ `${email}`+ '/'+ `${password}`, {
          method: 'GET'
        });
        const data = await response.json();
        localStorage.setItem("username", data.data.userName);
        localStorage.setItem("userId", data.data.userId);
        alert(data.message);
      }
    return(
        <div className='card'>
            <h2>Sign-in Here</h2>
            <form onSubmit={submitHandler}>
            <div>
                <label>Email</label>
                <input type="text" className='inputfields' value={email} onChange={(e) => setEmail(e.target.value)}></input>
            </div>
            <div>
                <label>Password</label>
                <input type="password" className='inputfields' value={password} onChange={(e) => setPassword(e.target.value)}></input>
            </div>
            <div>
                <label>submit</label>
                <input type="submit" className='inputfields'></input>
            </div>
            <div>
        </div>
        </form>
        </div>
    )
}
export default UserSigninCard;