import './index.css';
import {Link,useHistory} from 'react-router-dom';

const HotelCard=({image,name,type,totalrooms,roomsleft,price,rating,facilities,roomId})=>{
    return(
        <div className='hotelcard'>
            <div>
            <img src={image} loading="lazy" className='img'/>
            </div>
            <div className='details'>
                <p>{name}</p>
                <p>{facilities}</p>
                <p>Room Type: {type}</p>
                <p>Total Rooms: {totalrooms}</p>
                <p>Rooms Left: {roomsleft}</p>
                <p>Room Price: {price} $</p>
                <p>Room Rating: {rating}</p>
                <button><Link to={'/booking/'+`${roomId}`}>Book Now</Link></button>
            </div>
        </div>
    )
}
export default HotelCard;