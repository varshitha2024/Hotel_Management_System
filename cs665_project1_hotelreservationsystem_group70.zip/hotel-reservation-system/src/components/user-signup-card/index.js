import './index.css';
import React, {useState} from 'react';
import {Link,useHistory} from 'react-router-dom';

const UserSignupCard=()=>{

    const history = useHistory();

    const toSignin=()=>{
        history.push('/user-signin');

    }

    const [username, setUserName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");

    const submitHandler = (event) => {
        event.preventDefault();

        const userInfo = {
            userName: username,
            userEmail: email,
            userPassword: password
          };

        if(username=== ''){
            alert("Please enter Name");
        }
        else if(email=== ''){
                alert("Please Enter Email");
        }
        else if(password=== ''){
            alert("Please Enter Password");
        }
        else if(confirmPassword=== ''){
            alert("Pleas Confirm Password");
        }
        else if(!(password===confirmPassword)){
            alert("Please check passwords are not matching")
        }
        else{
            signupUserHandler(userInfo);
            history.push('/user-signin');
        }
      };

      const signupUserHandler = async (userInfo)=> {
        const response = await fetch('http://localhost:8080/api/signUpUser', {
          method: 'POST',
          body: JSON.stringify(userInfo),
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
          }
        });
        const data = await response.json();
        alert(data.message);
      }

    return(
        <div className='card'>
            <h2>Register Here</h2>
            <form onSubmit={submitHandler}>
            <div>
                <label>Username</label>
                <input type="text" className='inputfields' value={username} onChange={(e) => setUserName(e.target.value)}></input>
            </div>
            <div>
                <label>Email</label>
                <input type="email" className='inputfields' value={email} onChange={(e) => setEmail(e.target.value)}></input>
            </div>
            <div>
                <label>Password</label>
                <input type="password" className='inputfields' value={password} onChange={(e) => setPassword(e.target.value)}></input>
            </div>
            <div>
                <label> Confirm Password</label>
                <input type="password" className='inputfields' value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)}></input>
            </div>
            <div>
                <label>submit</label>
                <input type="submit" className='inputfields'></input>
            </div>
            <div>
        </div>
        </form>
        <h3>or if you are an Existing User sign-in</h3>
        <button  className='btn' onClick={toSignin}>Sign-in</button>
        </div>
    )
}
export default UserSignupCard;