import './index.css';
import {Link,useHistory} from 'react-router-dom';
import { useState } from 'react';

const HotelCardForBooking=({image,name,type,totalrooms,roomsleft,price,rating,facilities,roomId,noofbeds})=>{

    const [noofguests, setGuests] = useState(1);
    const [noofrooms, setRooms] = useState(1);
    const [email, setEmail] = useState("");
    const [checkin, setCheckin] = useState("");
    const [checkout, setCheckout] = useState("");

    const submitHandler = (event) => {
        event.preventDefault();
        const userInfo ={
            userId: localStorage.getItem('userId'),
            roomId: roomId,
            numberOfGuests: noofguests,
            numberOfRooms: noofrooms,
            checkInDate: checkin,
            checkOutDate:  checkout,
            imageUrl: image,
            facilities: facilities,
            amount: price
        };
        bookRoomHandler(userInfo);
        event.target.reset();
    }


    const bookRoomHandler = async (userInfo)=> {
        const response = await fetch('http://localhost:8080/api/bookRoom', {
          method: 'POST',
          body: JSON.stringify(userInfo),
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
          }
        });
        const data = await response.json();
        alert(data.message);
      }
    return(
        <div className='hotelcard54'>
            <div>
            <img src={image} loading="lazy" className='img'/>
            </div>
            <div className='details'>
                <p>Facilities: {facilities}</p>
                <p>Room Type: {type}</p>
                <p>No. of Beds: {noofbeds}</p>
                <p>Total Rooms: {totalrooms}</p>
                <p>Rooms Left: {roomsleft}</p>
                <p>Room Price: {price} $</p>
                <p>Room Rating: {rating}</p>
                <p>Enter payment details Below and Book Now</p>
                <form onSubmit={submitHandler}>
                <p>
                    <label>Number of Guests</label>
                    <input type="number" value={noofguests} onChange={(e) => setGuests(e.target.value)}></input>
                </p>
                <p>
                    <label>Number of Rooms</label>
                    <input type="number" value={noofrooms} onChange={(e) => setRooms(e.target.value)}></input>
                </p>
                <p>
                    <label>check-in</label>
                    <input type="date" va onChange={(e) => setCheckin(e.target.value)}></input>
                </p>
                <p>
                    <label>check-out</label>
                    <input type="date" onChange={(e) => setCheckout(e.target.value)}></input>
                </p>
                <p>
                    <label>Email</label>
                    <input type="Email"></input>
                </p>
                <p>
                    <label>Card Number</label>
                    <input type="text"></input>
                </p>
                <p>
                    <label>CVV Number</label>
                    <input type="text"></input>
                </p>
                <p>
                    <label>Confirm Booking</label>
                    <input type="submit" value='Book'></input>
                </p>
            <p>
        </p>
        </form>
            </div>
        </div>
    )
}
export default HotelCardForBooking;