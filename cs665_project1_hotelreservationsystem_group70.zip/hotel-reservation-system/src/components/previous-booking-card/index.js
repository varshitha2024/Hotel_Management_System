import './index.css';

const HotelCardPrevious=({image,facilities,roomId,amount,noofrooms,noofguests,checkin,checkout})=>{
    return(
        <div className='hotelcard'>
            <div>
            <img src={image} loading="lazy" className='img'/>
            </div>
            <div className='details'>
                <p>Amount: {amount}$</p>
                <p>Facilities: {facilities}</p>
                <p>Number of Rooms: {noofrooms}</p>
                <p>Number of Guests: {noofguests}</p>
                <p>Check-in Date: {checkin}</p>
                <p>Check-out Date: {checkout}</p>
            </div>
        </div>
    )
}
export default HotelCardPrevious;