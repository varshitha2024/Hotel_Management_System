import {Route, Switch} from 'react-router-dom';
import './App.css';
import LandingPage from './pages/landing-page';
import UserSignup from './pages/user-signup';
import AdminSignin from './pages/admin-signin';
import UserSignin from './pages/user-signin';
import Home from './pages/home-page';
import Admin from './pages/admin-page';
import UserProfile from './pages/userprofile-page';
import Bookings from './pages/bookings-page';
import PreviousBooking from './pages/previous-booking-page'
import AdminUpdateRoom from './pages/adminupdate-room-page';
import AdminAllBookings from './pages/admin-allbooking-page'
import AdminAddRoom from './pages/admin-addroom-page';
function App() {
  return (
    <div>
      <Switch>
          <Route path='/' exact component={LandingPage}/>
          <Route path='/user-signup' exact component={UserSignup}/>
          <Route path='/admin-signin' component={AdminSignin}/>
          <Route path='/user-signin' exact component={UserSignin}/>
          <Route path='/home' component={Home}/>
          <Route path='/admin' component={Admin}/>
          <Route path='/user-profile' exact component={UserProfile}/>
          <Route path='/booking/:roomId' component={Bookings}/>
          <Route path='/previous-bookings' exaxt component={PreviousBooking}/>
          <Route path='/admin-update-room' exaxt component={AdminUpdateRoom}/>
          <Route path='/admin-all-bookings' exaxt component={AdminAllBookings}/>
          <Route path='/admin-add-room' exaxt component={AdminAddRoom}/>
      </Switch>
    </div>
  );
}

export default App;
