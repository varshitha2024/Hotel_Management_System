import {Link,useHistory} from 'react-router-dom';
import './index.css';


const LandingPage = ()=>{


    const history = useHistory();

    const userHandler=()=>{
        history.push('/user-signup');
    }

    const adminHandler=()=>{
        history.push('/admin-signin');
    }

    return(
        <>
        <h1 className='heading'>Welcome to the Hotel Indigo Los Angeles Downtown</h1>
        <div className='btns'>
            <div className='btn1' onClick={userHandler}>Continue as Regular User </div>
            <div  className='btn2' onClick={adminHandler}> Continue as Admin </div>
        </div>
        </>
    )
}

export default LandingPage;