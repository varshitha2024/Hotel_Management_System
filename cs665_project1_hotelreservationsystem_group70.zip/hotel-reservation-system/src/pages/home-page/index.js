import './index.css';
import React, {useState} from 'react';
import {Link,useHistory} from 'react-router-dom';
import HotelCard from '../../components/hotel-card';
import {useEffect, useCallback} from 'react';

const Home =()=>{

    const history = useHistory();

    const [from, setFrom] = useState("");
    const [to, setTo] = useState("");
    const [number, setNumber] = useState(1);
    const [allHotels, setAllHotels] = useState([]);
    const [allHotelsView, setAllHotelsView] = useState(true);

    const [allHotelsQuery, setAllHotelsQuery] = useState([]);
    const [allHotelsQueryView, setAllHotelsQueryView] = useState(false);
    const [wifi, setWifi] = useState(false);
    const [refrigerator, setRefrigerator] = useState(false);
    const [breakfast, setBreakfast] = useState(false);
    const [tv, setTv] = useState(false);
    const [pool, setPool] = useState(false);
    const [bar, setBar] = useState(false);
    const [laundry, setLaundry] = useState(false);
    const [restaurant, setRestaurant] = useState(false);
    const [spa, setSpa] = useState(true);
    const [parking, setParking] = useState(false);
    const [confrenceroom, setConfrenceRoom] = useState(false);
    const [security, setSecurity] = useState(false);



    // const profileHandler=()=>{
    //     history.push('/user-profile');
    // }
    const previousHandler=()=>{
        history.push('/previous-bookings');
    }
    const logoutHandler=()=>{
        localStorage.removeItem("username");
        localStorage.removeItem("userId");
        history.push('/');
    }

    const getAllHotels= useCallback(async ()=> {
        const response =  await fetch('http://localhost:8080/api/getAllRoomHavingTotalRoomsGreaterThanZero/1/no');
        const data = await response.json();
        setAllHotels(data.data);
      }, []);
  
      useEffect(() => {
        getAllHotels();
      }, [getAllHotels]);


    const submitHandler=(event) => {
        event.preventDefault();
        setAllHotelsView(false);
        getHotelsQuery();
        setAllHotelsQueryView(true);
    }


    const getHotelsQuery= useCallback(async ()=> {
        // console.log(breakfast);
        var url ='http://localhost:8080/api/getAllRoomHavingTotalRoomsGreaterThanZero/'
        +`${number}`
        +'/'
        +`${((wifi==true?"WI-FI":''))}`
        +((refrigerator==true?",Refrigarator":''))
        +((breakfast==true?",Breakfast":''))
        +((tv==true?",TV":''))
        +((pool==true?",Swimming Pool":''))
        +((bar==true?",Bar":''))
        +((laundry==true?",Laundry Service":''))
        +((restaurant==true?",Restaurant":''))
        +((spa==true?",Spa":''))
        +((parking==true?",Car Parking":''))
        +((confrenceroom==true?",Conference Room":''))
        +((security==true?",24/7 Security":''));
        console.log(url);
        const response =  await fetch(url);
        const data = await response.json();
        setAllHotelsQuery(data.data);
        console.log(data);
      }, []);


    // console.log(
    //     'http://localhost:8080/api/getAllRoomHavingTotalRoomsGreaterThanZero/'
    //     +`${number}`
    //     +'/'
    //     +((wifi==true?"WI-FI":''))
    //     +((refrigerator==true?",Refrigarator":''))
    //     +((breakfast==true?",Breakfast":''))
    //     +((tv==true?",TV":''))
    //     +((pool==true?",Swimming Pool":''))
    //     +((bar==true?",Bar":''))
    //     +((laundry==true?",Laundry Service":''))
    //     +((restaurant==true?",Restaurant":''))
    //     +((spa==true?",Spa":''))
    //     +((parking==true?",Car Parking":''))
    //     +((confrenceroom==true?",Conference Room":''))
    //     +((security==true?",24/7 Security":''))
    // );

    return(
        <>
        <div className='head'>
        <h1 className='heading'>Welcome User {localStorage.getItem('username')}</h1>
        {/* <button className='btn' onClick={profileHandler}>View Profie</button> */}
        <button  className='btn' onClick={previousHandler}>See Previous Booking</button>
        <button  className='btn' onClick={logoutHandler}>Logout</button>
        </div>

        <div className='search1'>


        <form className='search2' onSubmit={submitHandler}>
        <h2>Search Here</h2>
            <div>
                <label className='heading'>Select Date from</label>
                <input type="date" className='inputfields' onChange={(e) => setFrom(e.target.value)}></input>
            </div>
            <div>
                <label className='heading'>Select Date to</label>
                <input type="date" className='inputfields' onChange={(e) => setTo(e.target.value)}></input>
            </div>
            <div>
                <label className='heading'>Number of People</label>
                <input type="number" className='inputfields' onChange={(e) => {
                    e.preventDefault();
                    setNumber(e.target.value)}}></input>
            </div>
            <div>
                <label className='heading'>WI-FI</label>
                <input type="checkbox" onChange={(e) =>{
                    e.preventDefault();
                    setWifi(true)
                }}></input>
            </div>
            <div>
                <label className='heading'>Refrigerator</label>
                <input type="checkbox" onChange={(e) => {
                    e.preventDefault();
                    setRefrigerator(true)}}></input>
            </div>
            <div>
                <label className='heading'>Breakfast</label>
                <input type="checkbox" onChange={(e) => 
                    {
                        e.preventDefault();
                        setBreakfast(true)
                    }}></input>
            </div>
            <div>
                <label className='heading'>Tv</label>
                <input type="checkbox" onChange={(e) => {
                    e.preventDefault();
                    setTv(true)}}></input>
            </div>
            <div>
                <label className='heading'>Swimming Pool</label>
                <input type="checkbox"  onChange={(e) => {
                    e.preventDefault();
                    setPool(true)}}></input>
            </div>
            <div>
                <label className='heading'>Bar</label>
                <input type="checkbox" onChange={(e) => {
                    e.preventDefault();
                    setBar(true)}}></input>
            </div>
            <div>
                <label className='heading'>Laundry Service</label>
                <input type="checkbox" onChange={(e) => {
                    e.preventDefault();
                    setLaundry(true)}}></input>
            </div>
            <div>
                <label className='heading'>Restaurant</label>
                <input type="checkbox" onChange={(e) => {
                    e.preventDefault();
                    setRestaurant(true)}}></input>
            </div>
            <div>
                <label className='heading'>Spa</label>
                <input type="checkbox" onChange={(e) => {
                    e.preventDefault();
                    setSpa(true)}}></input>
            </div>
            <div>
                <label className='heading'>Car Parking</label>
                <input type="checkbox" onChange={(e) => {
                    e.preventDefault();
                    setParking(true)}}></input>
            </div>
            <div>
                <label className='heading'>Confrence Room</label>
                <input type="checkbox" onChange={(e) => {
                    e.preventDefault();
                    setConfrenceRoom(true)}}></input>
            </div>
            <div>
                <label className='heading'>24/7 Security</label>
                <input type="checkbox" onChange={(e) => {
                    e.preventDefault();
                    setSecurity(true)}}></input>
            </div>
            <div>
                <label className='heading'>Search</label>
                <input type="submit" className='inputfields' value='Search'></input>
            </div>
        </form>

        <div>
            {allHotelsView && 
            <>
            <h1>{allHotels.length} types of room available</h1>
                {allHotels.map(option=>(
                <HotelCard  
                rating={option.roomRating}
                price={option.roomPrice}
                roomsleft={option.roomsLeft}
                totalrooms={option.totalRooms}
                type={option.roomType}
                name={'The Hotel Indigo Los Angeles Downtown'}
                facilities={option.facilities}
                image={option.imageUrl}
                roomId={option.roomId}
                />
                ))}
            </>
            }
            {allHotelsQueryView && 
            <>
            <h1>{allHotelsQuery.length} types of room available</h1>
                {allHotelsQuery.map(option=>(
                <HotelCard  
                rating={option.roomRating}
                price={option.roomPrice}
                roomsleft={option.roomsLeft}
                totalrooms={option.totalRooms}
                type={option.roomType}
                name={'The Hotel Indigo Los Angeles Downtown'}
                facilities={option.facilities}
                image={option.imageUrl}
                roomId={option.roomId}
                />
                ))}
            </>
            }
        </div>

        </div>
        </>
    )
}
export default Home;