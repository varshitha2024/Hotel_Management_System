import {useHistory} from 'react-router-dom';
import './index.css';
import React, {useState} from 'react';
import UserSignupCard from '../../components/user-signup-card';


const UserSignup = ()=>{


    return(
        <>
        <h1 className='head'>New User Sign-up Here</h1>
        <UserSignupCard/>
        </>
       
    )
}

export default UserSignup;