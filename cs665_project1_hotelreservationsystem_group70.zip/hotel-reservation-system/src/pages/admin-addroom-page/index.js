import './index.css';
import CardAdminRoomAdd from '../../components/card-addroom-admin';
const AdminAddRoom =()=>{



    return(
        <>
        <h1 className='heading11'>Admin Add Room</h1>
        <CardAdminRoomAdd/>
        </>
    )
}
export default AdminAddRoom;