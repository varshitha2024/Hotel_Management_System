const UserProfile=()=>{
    return(
        <h1>User Profile Page</h1>
    )
}
export default UserProfile;