import { useParams } from 'react-router-dom';
import React, { useState, useEffect, useCallback} from 'react';
import HotelCardForBooking from '../../components/hotel-card-for-booking';
import './index.css';


const Bookings=()=>{
    const [hotelDetails, setHotelDetails] = useState({});

    const params = useParams();

    const getHotelDetails = useCallback(async ()=> {
        const response =  await fetch('http://localhost:8080/api/getRoomById/'+`${params.roomId}`);
        const data = await response.json();
        setHotelDetails(data.data);
      }, []);
  
      useEffect(() => {
        getHotelDetails();
      }, [getHotelDetails]);

    return(
        <>
        <h1 className='heading'>Book Hotel</h1>
        <div>
            <HotelCardForBooking  
                rating={hotelDetails.roomRating}
                price={hotelDetails.roomPrice}
                facilities={hotelDetails.facilities}
                totalrooms= {hotelDetails.totalRooms}
                roomsleft={hotelDetails.roomsLeft}
                image={hotelDetails.imageUrl}
                roomId={hotelDetails.roomId}
                noofbeds={hotelDetails.numberOfBeds}
                type={hotelDetails.roomType}
            />
        </div>
        </>
    )
}
export default Bookings;