import AdminSigninCard from "../../components/admin-signin-card";

const AdminSignin = ()=>{
    return(
        <>
        <h1 className='head'>Admin Sign-in Here</h1>
        <AdminSigninCard/>
        </>
    )
}

export default AdminSignin;