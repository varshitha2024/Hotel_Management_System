import './index.css';
import HotelCardPrevious from '../../components/previous-booking-card';
import React, { useState, useEffect, useCallback} from 'react';
const AdminAllBookings =()=>{
    const [allbookingsAdmin, setAllBookingsAdmin] = useState([]);

    const getAllBookingAdmin = useCallback(async ()=> {
        const response =  await fetch('http://localhost:8080/api/getAllBookingsByAdmin');
        const data = await response.json();
        setAllBookingsAdmin(data.data);
      }, []);
  
      useEffect(() => {
        getAllBookingAdmin();
      }, [getAllBookingAdmin]);
    
      
    return(
        <>
        <h1 className='heading11'>All Bookings</h1>
        <h1 className='heading11'>{allbookingsAdmin.length} Bookings Total</h1>
        {allbookingsAdmin.map(option=>(
                <HotelCardPrevious  
                rating={option.roomRating}
                price={option.roomPrice}
                noofrooms= {option.numberOfRooms}
                noofguests= {option.numberOfGuests}
                facilities={option.facilities}
                image={option.imageUrl}
                roomId={option.roomId}
                checkin= {option.checkInDate}
                checkout= {option.checkOutDate}
                amount={option.amount}
                />
                ))}
        </>
    )
}
export default AdminAllBookings;