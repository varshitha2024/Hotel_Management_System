import './index.css';

const AdminUpdateRoom=()=>{
    return(
    <h1 className='heading'>Work in Progress</h1>
    )

}
export default AdminUpdateRoom;