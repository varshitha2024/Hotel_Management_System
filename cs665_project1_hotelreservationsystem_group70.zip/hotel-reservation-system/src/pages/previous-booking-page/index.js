import { useParams } from 'react-router-dom';
import React, { useState, useEffect, useCallback} from 'react';
import HotelCardPrevious from '../../components/previous-booking-card';
import './index.css';


const Bookings=()=>{

    const [prevbookings, setPrevBookings] = useState([]);

    const getBookings = useCallback(async ()=> {
        const response =  await fetch('http://localhost:8080/api/getAllBookings/'+`${localStorage.getItem('userId')}`);
        const data = await response.json();
        setPrevBookings(data.data);
      }, []);
  
      useEffect(() => {
        getBookings();
      }, [getBookings]);


    return(
        <>
        <h1 className='heading'>Your Previous Bookings Page</h1>
        <div>
        {prevbookings.map(option=>(
                <HotelCardPrevious  
                rating={option.roomRating}
                price={option.roomPrice}
                noofrooms= {option.numberOfRooms}
                noofguests= {option.numberOfGuests}
                facilities={option.facilities}
                image={option.imageUrl}
                roomId={option.roomId}
                checkin= {option.checkInDate}
                checkout= {option.checkOutDate}
                amount={option.amount}
                />
                ))}
        </div>
        </>
    )
}
export default Bookings;