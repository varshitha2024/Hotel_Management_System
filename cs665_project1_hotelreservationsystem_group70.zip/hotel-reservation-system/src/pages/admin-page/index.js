import './index.css';
import {Link,useHistory} from 'react-router-dom';

const Admin =()=>{
    const history = useHistory();

    const adminLogoutHandler=()=>{
        localStorage.removeItem("adminId");
        localStorage.removeItem("adminName");
        localStorage.removeItem("adminEmail");
        history.push('/');
    }
    const updateroomHandler=()=>{
        history.push('/admin-update-room');
    }
    const seeBookingsHandler=()=>{
        history.push('/admin-all-bookings');
    }
    const addRoomHandler=()=>{
        history.push('/admin-add-room');
    }
    return(
        <>
        <h1 className='heading11'>Welcome to the Hotel Indigo Los Angeles Downtown Admin Panel</h1>
        <div className='btns'>
            <button className='btnn1' onClick={seeBookingsHandler}>See Bookings</button>
            <button className='btnn2' onClick={addRoomHandler}>Add Rooms</button>
            <button className='btnn3' onClick={updateroomHandler}>Update Rooms</button>
        </div>
        <div className='btns2'>
            <button className='btnn4' onClick={adminLogoutHandler}>Logout</button>
        </div>
        </>
    )
}
export default Admin;